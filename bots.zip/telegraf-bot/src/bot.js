require('dotenv').config();
const HttpsProxyAgent = require('https-proxy-agent')
const Telegraf = require('telegraf');

let telegramProxyConfig = {};
if (process.env.PROXY_USE) {
  console.log("Используется прокси ....")
  const { PROXY_IP, PROXY_USERNAME, PROXY_PASSWORD, PROXY_PORT } = process.env;
  const proxyUrl = `http://${PROXY_USERNAME}:${PROXY_PASSWORD}@${PROXY_IP}:${PROXY_PORT}`
  telegramProxyConfig = {
    telegram: {
      agent: new HttpsProxyAgent(proxyUrl)
    }
  }
}
module.exports = new Telegraf(process.env.TELEGRAM_TOKEN, telegramProxyConfig);

// const bot = new Telegraf('token', {
//   telegram: {
//     agent: new HttpsProxyAgent('http://login:pass@ip:port')
//   }
// });