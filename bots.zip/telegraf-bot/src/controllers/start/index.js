const Scene = require('telegraf/scenes/base')
const { leave } = require('telegraf/stage')
const User = require('../../models/User')

const startScene = new Scene('start')

startScene.enter(async (ctx) => {
  const uid = String(ctx.from.id);
  await ctx.reply('Hi' + uid);
  const user = await User.findById(uid);
  console.log(`user = ${user}`);
  if (user) {
    ///
    await ctx.reply('Рад снова тебя видеть')
  } else {
    const now = new Date().getTime();

    const newUser = new User({
      _id: uid,
      created: now,
      username: ctx.from.username,
      name: ctx.from.first_name + ' ' + ctx.from.last_name,
      observableMovies: [],
      lastActivity: now,
      totalMovies: 0,
      language: 'en'
    });

    await newUser.save();
    await ctx.reply('Пользователь сохранен');
  }
})

module.exports = startScene;