require('dotenv').config();

const Stage = require('telegraf/stage')
const session = require('telegraf/session')
const startScene = require('./controllers/start')
const db = require('./db');

db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
  console.log('База данных подключена...')
  const bot = require('./bot');
  // Create scene manager
  const stage = new Stage()
  //stage.command('cancel', leave())

  // Scene registration
  stage.register(startScene)

  bot.use(session())
  bot.use(stage.middleware())
  bot.command('tes', (ctx) => ctx.scene.enter('start'))
  bot.startPolling()
});



