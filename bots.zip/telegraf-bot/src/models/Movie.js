const mongoose = require('mongoose');

const MovieSchema = new mongoose.Schema(
  {
    _id: String,
      title: String,
    year: Number,
    posterUrl: String,
    language: String,
    released: Boolean
  },
  { _id: false }
)

const Movie = mongoose.model('Movie', MovieSchema);

module.exports = Movie;