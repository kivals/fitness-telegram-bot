const mongoose = require('mongoose');
require('./Movie');
const UserSchema = new mongoose.Schema({
    _id: String,
    created: Number,
    username: String,
    name: String,
    observableMovies: [
      {
        type: String,
        ref: 'Movie'
      }
    ],
    lastActivity: Number,
    language: String,
    totalMovies: Number
  },
  { _id: false }
)

UserSchema.pre('find', () => {
  console.log('PRE FIND')
}).pre('findOne', () => {
  console.log('PRE FINDONE')
});

const User = mongoose.model('User', UserSchema);

module.exports = User;