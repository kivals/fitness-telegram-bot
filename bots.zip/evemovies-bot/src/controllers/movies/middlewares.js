"use strict";
exports.__esModule = true;
exports.exposeMovie = void 0;
/**
 * Exposes required movie according to the given callback data
 * @param ctx - telegram context
 * @param next - next function
 */
function exposeMovie(ctx, next) {
    var action = JSON.parse(ctx.callbackQuery.data);
    ctx.movie = ctx.session.movies.find(function (item) { return item._id === action.p; });
    return next();
}
exports.exposeMovie = exposeMovie;
