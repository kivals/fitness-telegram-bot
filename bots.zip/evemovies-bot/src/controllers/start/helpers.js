"use strict";
exports.__esModule = true;
exports.getAccountConfirmKeyboard = exports.getLanguageKeyboard = void 0;
var telegraf_1 = require("telegraf");
/**
 * Displays menu with a list of movies
 * @param movies - list of movies
 */
/**
 * Returns language keyboard
 */
function getLanguageKeyboard() {
    return telegraf_1.Extra.HTML().markup(function (m) {
        return m.inlineKeyboard([
            m.callbackButton("English", JSON.stringify({ a: 'languageChange', p: 'en' }), false),
            m.callbackButton("\u0420\u0443\u0441\u0441\u043A\u0438\u0439", JSON.stringify({ a: 'languageChange', p: 'ru' }), false)
        ], {});
    });
}
exports.getLanguageKeyboard = getLanguageKeyboard;
/**
 * Returns button that user has to click to start working with the bot
 */
function getAccountConfirmKeyboard(ctx) {
    return telegraf_1.Extra.HTML().markup(function (m) {
        return m.inlineKeyboard([
            m.callbackButton(ctx.i18n.t('scenes.start.lets_go'), JSON.stringify({ a: 'confirmAccount' }), false)
        ], {});
    });
}
exports.getAccountConfirmKeyboard = getAccountConfirmKeyboard;
