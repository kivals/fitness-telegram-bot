"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
exports.__esModule = true;
exports.closeAccountSummaryAction = exports.accountSummaryAction = exports.languageChangeAction = exports.languageSettingsAction = void 0;
var helpers_1 = require("./helpers");
var logger_1 = require("../../util/logger");
var User_1 = require("../../models/User");
var language_1 = require("../../util/language");
var keyboards_1 = require("../../util/keyboards");
var session_1 = require("../../util/session");
var languageSettingsAction = function (ctx) { return __awaiter(void 0, void 0, void 0, function () { return __generator(this, function (_a) {
    switch (_a.label) {
        case 0: return [4 /*yield*/, ctx.editMessageText(ctx.i18n.t('scenes.settings.pick_language'), helpers_1.getLanguageKeyboard())];
        case 1: return [2 /*return*/, _a.sent()];
    }
}); }); };
exports.languageSettingsAction = languageSettingsAction;
var languageChangeAction = function (ctx) { return __awaiter(void 0, void 0, void 0, function () {
    var langData, backKeyboard, _i, _a, msg;
    return __generator(this, function (_b) {
        switch (_b.label) {
            case 0:
                langData = JSON.parse(ctx.callbackQuery.data);
                return [4 /*yield*/, language_1.updateLanguage(ctx, langData.p)];
            case 1:
                _b.sent();
                backKeyboard = keyboards_1.getBackKeyboard(ctx).backKeyboard;
                _i = 0, _a = ctx.session.settingsScene.messagesToDelete;
                _b.label = 2;
            case 2:
                if (!(_i < _a.length)) return [3 /*break*/, 5];
                msg = _a[_i];
                return [4 /*yield*/, ctx.telegram.deleteMessage(msg.chatId, msg.messageId)];
            case 3:
                _b.sent();
                _b.label = 4;
            case 4:
                _i++;
                return [3 /*break*/, 2];
            case 5:
                session_1.deleteFromSession(ctx, 'settingsScene');
                return [4 /*yield*/, helpers_1.sendMessageToBeDeletedLater(ctx, 'scenes.settings.language_changed', helpers_1.getMainKeyboard(ctx))];
            case 6:
                _b.sent();
                return [4 /*yield*/, helpers_1.sendMessageToBeDeletedLater(ctx, 'scenes.settings.what_to_change', backKeyboard)];
            case 7:
                _b.sent();
                return [2 /*return*/];
        }
    });
}); };
exports.languageChangeAction = languageChangeAction;
var accountSummaryAction = function (ctx) { return __awaiter(void 0, void 0, void 0, function () {
    var user;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                logger_1["default"].debug(ctx, 'Checking account summary');
                return [4 /*yield*/, User_1["default"].findById(ctx.from.id)];
            case 1:
                user = _a.sent();
                return [4 /*yield*/, ctx.editMessageText(ctx.i18n.t('scenes.settings.account_summary', {
                        username: user.username,
                        id: user._id,
                        totalMovies: user.totalMovies,
                        version: process.env.npm_package_version
                    }), helpers_1.getAccountSummaryKeyboard(ctx))];
            case 2:
                _a.sent();
                return [4 /*yield*/, ctx.answerCbQuery()];
            case 3:
                _a.sent();
                return [2 /*return*/];
        }
    });
}); };
exports.accountSummaryAction = accountSummaryAction;
var closeAccountSummaryAction = function (ctx) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, ctx.editMessageText(ctx.i18n.t('scenes.settings.what_to_change'), helpers_1.getMainKeyboard(ctx))];
            case 1:
                _a.sent();
                return [4 /*yield*/, ctx.answerCbQuery()];
            case 2:
                _a.sent();
                return [2 /*return*/];
        }
    });
}); };
exports.closeAccountSummaryAction = closeAccountSummaryAction;
