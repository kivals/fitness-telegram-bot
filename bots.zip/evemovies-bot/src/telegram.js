"use strict";
exports.__esModule = true;
var telegraf_1 = require("telegraf");
var telegram = new telegraf_1.Telegram(process.env.TELEGRAM_TOKEN, {});
exports["default"] = telegram;
