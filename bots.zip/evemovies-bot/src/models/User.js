"use strict";
exports.__esModule = true;
exports.UserSchema = void 0;
var mongoose_1 = require("mongoose");
exports.UserSchema = new mongoose_1["default"].Schema({
    _id: String,
    created: Number,
    username: String,
    name: String,
    observableMovies: [
        {
            type: String,
            ref: 'Movie'
        }
    ],
    lastActivity: Number,
    language: String,
    totalMovies: Number
}, { _id: false });
exports.UserSchema.pre('find', function () {
    this.populate('observableMovies');
}).pre('findOne', function () {
    this.populate('observableMovies');
});
var User = mongoose_1["default"].model('User', exports.UserSchema);
exports["default"] = User;
