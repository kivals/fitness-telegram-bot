"use strict";
exports.__esModule = true;
exports.MovieSchema = void 0;
var mongoose_1 = require("mongoose");
exports.MovieSchema = new mongoose_1["default"].Schema({
    _id: String,
    title: String,
    year: Number,
    posterUrl: String,
    language: String,
    released: Boolean
}, { _id: false });
var Movie = mongoose_1["default"].model('Movie', exports.MovieSchema);
exports["default"] = Movie;
