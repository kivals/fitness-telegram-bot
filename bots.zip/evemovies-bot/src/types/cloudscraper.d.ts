declare module 'cloudscraper';
