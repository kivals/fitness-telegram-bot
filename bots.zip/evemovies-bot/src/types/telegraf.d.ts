declare module 'telegraf/session';
declare module 'telegraf/stage';
declare module 'telegraf/scenes/base';
