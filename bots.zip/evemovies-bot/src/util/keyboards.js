"use strict";
exports.__esModule = true;
exports.getMainKeyboard = exports.getBackKeyboard = void 0;
var telegraf_1 = require("telegraf");
/**
 * Returns back keyboard and its buttons according to the language
 * @param ctx - telegram context
 */
var getBackKeyboard = function (ctx) {
    var backKeyboardBack = ctx.i18n.t('keyboards.back_keyboard.back');
    var backKeyboard = telegraf_1.Markup.keyboard([backKeyboardBack]);
    backKeyboard = backKeyboard.resize().extra();
    return {
        backKeyboard: backKeyboard,
        backKeyboardBack: backKeyboardBack
    };
};
exports.getBackKeyboard = getBackKeyboard;
/**
 * Returns main keyboard and its buttons according to the language
 * @param ctx - telegram context
 */
var getMainKeyboard = function (ctx) {
    var mainKeyboardSearchMovies = ctx.i18n.t('keyboards.main_keyboard.search');
    var mainKeyboardMyCollection = ctx.i18n.t('keyboards.main_keyboard.movies');
    var mainKeyboardSettings = ctx.i18n.t('keyboards.main_keyboard.settings');
    var mainKeyboardAbout = ctx.i18n.t('keyboards.main_keyboard.about');
    var mainKeyboardSupport = ctx.i18n.t('keyboards.main_keyboard.support');
    var mainKeyboardContact = ctx.i18n.t('keyboards.main_keyboard.contact');
    var mainKeyboard = telegraf_1.Markup.keyboard([
        [mainKeyboardSearchMovies, mainKeyboardMyCollection],
        [mainKeyboardSettings, mainKeyboardAbout],
        [mainKeyboardSupport, mainKeyboardContact]
    ]);
    mainKeyboard = mainKeyboard.resize().extra();
    return {
        mainKeyboard: mainKeyboard,
        mainKeyboardSearchMovies: mainKeyboardSearchMovies,
        mainKeyboardMyCollection: mainKeyboardMyCollection,
        mainKeyboardSettings: mainKeyboardSettings,
        mainKeyboardAbout: mainKeyboardAbout,
        mainKeyboardSupport: mainKeyboardSupport,
        mainKeyboardContact: mainKeyboardContact
    };
};
exports.getMainKeyboard = getMainKeyboard;
