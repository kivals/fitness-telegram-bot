"use strict";
var __spreadArrays = (this && this.__spreadArrays) || function () {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
};
exports.__esModule = true;
var util_1 = require("util");
var winston_1 = require("winston");
/**
 * Adds user id and nickname if found. Also formats message to display complex objects
 * @param ctx - telegram context
 * @param msg  - message
 * @param data - object to log
 */
function prepareMessage(ctx, msg) {
    var data = [];
    for (var _i = 2; _i < arguments.length; _i++) {
        data[_i - 2] = arguments[_i];
    }
    var formattedMessage = data.length ? util_1["default"].format.apply(util_1["default"], __spreadArrays([msg], data)) : msg;
    if (ctx && ctx.from) {
        return "[" + ctx.from.id + "/" + ctx.from.username + "]: " + formattedMessage;
    }
    return ": " + formattedMessage;
}
var combine = winston_1.format.combine, timestamp = winston_1.format.timestamp, printf = winston_1.format.printf;
var logFormat = printf(function (info) {
    return "[" + info.timestamp + "] [" + info.level + "]" + info.message;
});
var logger = winston_1["default"].createLogger({
    transports: [
        new winston_1["default"].transports.Console({
            level: process.env.NODE_ENV === 'production' ? 'error' : 'debug'
        }),
        new winston_1["default"].transports.File({ filename: 'debug.log', level: 'debug' })
    ],
    format: combine(timestamp(), winston_1.format.splat(), winston_1.format.simple(), logFormat)
});
if (process.env.NODE_ENV !== 'production') {
    logger.debug('Logging initialized at debug level');
}
var loggerWithCtx = {
    debug: function (ctx, msg) {
        var data = [];
        for (var _i = 2; _i < arguments.length; _i++) {
            data[_i - 2] = arguments[_i];
        }
        return logger.debug(prepareMessage.apply(void 0, __spreadArrays([ctx, msg], data)));
    },
    error: function (ctx, msg) {
        var data = [];
        for (var _i = 2; _i < arguments.length; _i++) {
            data[_i - 2] = arguments[_i];
        }
        return logger.error(prepareMessage.apply(void 0, __spreadArrays([ctx, msg], data)));
    }
};
exports["default"] = loggerWithCtx;
