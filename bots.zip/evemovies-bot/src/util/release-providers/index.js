"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
exports.__esModule = true;
exports.ytsReleaseChecker = exports.scarabeyReleaseChecker = void 0;
var scarabey_1 = require("./scarabey");
__createBinding(exports, scarabey_1, "scarabeyReleaseChecker");
var yts_1 = require("./yts");
__createBinding(exports, yts_1, "ytsReleaseChecker");
