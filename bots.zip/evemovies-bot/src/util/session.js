"use strict";
exports.__esModule = true;
exports.deleteFromSession = exports.saveToSession = void 0;
var logger_1 = require("./logger");
/**
 * Saving data to the session
 * @param ctx - telegram context
 * @param field - field to store in
 * @param data - data to store
 */
function saveToSession(ctx, field, data) {
    logger_1["default"].debug(ctx, 'Saving %s to session', field);
    ctx.session[field] = data;
}
exports.saveToSession = saveToSession;
/**
 * Removing data from the session
 * @param ctx - telegram context
 * @param field - field to delete
 */
function deleteFromSession(ctx, field) {
    logger_1["default"].debug(ctx, 'Deleting %s from session', field);
    delete ctx.session[field];
}
exports.deleteFromSession = deleteFromSession;
