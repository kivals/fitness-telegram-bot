"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
exports.__esModule = true;
require('dotenv').config();
require('./models');
var fs_1 = require("fs");
var path_1 = require("path");
var telegraf_1 = require("telegraf");
var telegraf_i18n_1 = require("telegraf-i18n");
var stage_1 = require("telegraf/stage");
var session_1 = require("telegraf/session");
var mongoose_1 = require("mongoose");
var request_promise_1 = require("request-promise");
var User_1 = require("./models/User");
var logger_1 = require("./util/logger");
var about_1 = require("./controllers/about");
var start_1 = require("./controllers/start");
var search_1 = require("./controllers/search");
var movies_1 = require("./controllers/movies");
var settings_1 = require("./controllers/settings");
var contact_1 = require("./controllers/contact");
var admin_1 = require("./controllers/admin");
var notifier_1 = require("./util/notifier");
var error_handler_1 = require("./util/error-handler");
var keyboards_1 = require("./util/keyboards");
var language_1 = require("./util/language");
var update_user_timestamp_1 = require("./middlewares/update-user-timestamp");
var user_info_1 = require("./middlewares/user-info");
var is_admin_1 = require("./middlewares/is-admin");
var telegram_1 = require("./telegram");
mongoose_1["default"].connect("mongodb://localhost:27017/" + process.env.DATABASE_HOST, {
    useNewUrlParser: true,
    useFindAndModify: false
});
mongoose_1["default"].connection.on('error', function (err) {
    logger_1["default"].error(undefined, "Error occurred during an attempt to establish connection with the database: %O", err);
    process.exit(1);
});
mongoose_1["default"].connection.on('open', function () {
    var bot = new telegraf_1["default"](process.env.TELEGRAM_TOKEN);
    var stage = new stage_1["default"]([
        start_1["default"],
        search_1["default"],
        movies_1["default"],
        settings_1["default"],
        contact_1["default"],
        admin_1["default"]
    ]);
    var i18n = new telegraf_i18n_1["default"]({
        defaultLanguage: 'en',
        directory: path_1["default"].resolve(__dirname, 'locales'),
        useSession: true,
        allowMissing: false,
        sessionName: 'session'
    });
    bot.use(session_1["default"]());
    bot.use(i18n.middleware());
    bot.use(stage.middleware());
    bot.use(user_info_1.getUserInfo);
    bot.command('saveme', function (ctx) { return __awaiter(void 0, void 0, void 0, function () {
        var mainKeyboard;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    logger_1["default"].debug(ctx, 'User uses /saveme command');
                    mainKeyboard = keyboards_1.getMainKeyboard(ctx).mainKeyboard;
                    return [4 /*yield*/, ctx.reply(ctx.i18n.t('shared.what_next'), mainKeyboard)];
                case 1:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    }); });
    bot.start(error_handler_1["default"](function (ctx) { return __awaiter(void 0, void 0, void 0, function () { return __generator(this, function (_a) {
        return [2 /*return*/, ctx.scene.enter('start')];
    }); }); }));
    bot.hears(telegraf_i18n_1.match('keyboards.main_keyboard.search'), update_user_timestamp_1.updateUserTimestamp, error_handler_1["default"](function (ctx) { return __awaiter(void 0, void 0, void 0, function () { return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, ctx.scene.enter('search')];
            case 1: return [2 /*return*/, _a.sent()];
        }
    }); }); }));
    bot.hears(telegraf_i18n_1.match('keyboards.main_keyboard.movies'), update_user_timestamp_1.updateUserTimestamp, error_handler_1["default"](function (ctx) { return __awaiter(void 0, void 0, void 0, function () { return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, ctx.scene.enter('movies')];
            case 1: return [2 /*return*/, _a.sent()];
        }
    }); }); }));
    bot.hears(telegraf_i18n_1.match('keyboards.main_keyboard.settings'), update_user_timestamp_1.updateUserTimestamp, error_handler_1["default"](function (ctx) { return __awaiter(void 0, void 0, void 0, function () { return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, ctx.scene.enter('settings')];
            case 1: return [2 /*return*/, _a.sent()];
        }
    }); }); }));
    bot.hears(telegraf_i18n_1.match('keyboards.main_keyboard.about'), update_user_timestamp_1.updateUserTimestamp, error_handler_1["default"](about_1["default"]));
    bot.hears(telegraf_i18n_1.match('keyboards.main_keyboard.contact'), update_user_timestamp_1.updateUserTimestamp, error_handler_1["default"](function (ctx) { return __awaiter(void 0, void 0, void 0, function () { return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, ctx.scene.enter('contact')];
            case 1: return [2 /*return*/, _a.sent()];
        }
    }); }); }));
    bot.hears(telegraf_i18n_1.match('keyboards.back_keyboard.back'), error_handler_1["default"](function (ctx) { return __awaiter(void 0, void 0, void 0, function () {
        var mainKeyboard;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    // If this method was triggered, it means that bot was updated when user was not in the main menu..
                    logger_1["default"].debug(ctx, 'Return to the main menu with the back button');
                    mainKeyboard = keyboards_1.getMainKeyboard(ctx).mainKeyboard;
                    return [4 /*yield*/, ctx.reply(ctx.i18n.t('shared.what_next'), mainKeyboard)];
                case 1:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    }); }));
    bot.hears(telegraf_i18n_1.match('keyboards.main_keyboard.support'), error_handler_1["default"](function (ctx) { return __awaiter(void 0, void 0, void 0, function () {
        var supportKeyboard;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    logger_1["default"].debug(ctx, 'Opened support options');
                    supportKeyboard = telegraf_1.Extra.HTML().markup(function (m) {
                        return m.inlineKeyboard([
                            [m.urlButton("Patreon", process.env.PATREON_LINK, false)],
                            [m.urlButton("Paypal", process.env.PAYPAL_LINK, false)],
                            [m.urlButton("Yandex.Money", process.env.YANDEX_LINK, false)],
                            [m.urlButton("WebMoney", process.env.WEBMONEY_LINK, false)]
                        ], {});
                    });
                    return [4 /*yield*/, ctx.reply(ctx.i18n.t('other.support'), supportKeyboard)];
                case 1:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    }); }));
    bot.hears(/(.*admin)/, is_admin_1.isAdmin, error_handler_1["default"](function (ctx) { return __awaiter(void 0, void 0, void 0, function () { return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, ctx.scene.enter('admin')];
            case 1: return [2 /*return*/, _a.sent()];
        }
    }); }); }));
    bot.hears(/(.*?)/, function (ctx) { return __awaiter(void 0, void 0, void 0, function () {
        var user, mainKeyboard;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    logger_1["default"].debug(ctx, 'Default handler has fired');
                    return [4 /*yield*/, User_1["default"].findById(ctx.from.id)];
                case 1:
                    user = _a.sent();
                    return [4 /*yield*/, language_1.updateLanguage(ctx, user.language)];
                case 2:
                    _a.sent();
                    mainKeyboard = keyboards_1.getMainKeyboard(ctx).mainKeyboard;
                    return [4 /*yield*/, ctx.reply(ctx.i18n.t('other.default_handler'), mainKeyboard)];
                case 3:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    }); });
    bot["catch"](function (error) {
        logger_1["default"].error(undefined, 'Global error has happened, %O', error);
    });
    setInterval(notifier_1.checkUnreleasedMovies, 86400000);
    process.env.NODE_ENV === 'production' ? startProdMode(bot) : startDevMode(bot);
});
function startDevMode(bot) {
    logger_1["default"].debug(undefined, 'Starting a bot in development mode');
    request_promise_1["default"]("https://api.telegram.org/bot" + process.env.TELEGRAM_TOKEN + "/deleteWebhook").then(function () {
        return bot.startPolling();
    });
}
function startProdMode(bot) {
    return __awaiter(this, void 0, void 0, function () {
        var tlsOptions, webhookStatus;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    // If webhook not working, check fucking motherfucking UFW that probably blocks a port...
                    logger_1["default"].debug(undefined, 'Starting a bot in production mode');
                    tlsOptions = {
                        key: fs_1["default"].readFileSync(process.env.PATH_TO_KEY),
                        cert: fs_1["default"].readFileSync(process.env.PATH_TO_CERT)
                    };
                    return [4 /*yield*/, bot.telegram.setWebhook("https://dmbaranov.io:" + process.env.WEBHOOK_PORT + "/" + process.env.TELEGRAM_TOKEN, {
                            source: 'cert.pem'
                        })];
                case 1:
                    _a.sent();
                    return [4 /*yield*/, bot.startWebhook("/" + process.env.TELEGRAM_TOKEN, tlsOptions, +process.env.WEBHOOK_PORT)];
                case 2:
                    _a.sent();
                    return [4 /*yield*/, telegram_1["default"].getWebhookInfo()];
                case 3:
                    webhookStatus = _a.sent();
                    console.log('Webhook status', webhookStatus);
                    notifier_1.checkUnreleasedMovies();
                    return [2 /*return*/];
            }
        });
    });
}
